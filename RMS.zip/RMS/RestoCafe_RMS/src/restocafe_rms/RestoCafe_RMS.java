
package restocafe_rms;

public class RestoCafe_RMS {


    public static void main(String[] args) {
        GetStarted GSFrame = new GetStarted();
        GSFrame.setVisible(true);
        GSFrame.pack();
        GSFrame.setLocationRelativeTo(null); 
      
    }
}
